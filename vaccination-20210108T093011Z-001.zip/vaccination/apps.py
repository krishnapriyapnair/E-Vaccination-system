from django.apps import AppConfig


class VaccinationConfig(AppConfig):
    name = 'vaccination'
